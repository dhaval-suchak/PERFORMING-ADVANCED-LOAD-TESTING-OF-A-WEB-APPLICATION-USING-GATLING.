package computerdatabase

import io.gatling.core.Predef._
import io.gatling.http.Predef._
import scala.concurrent.duration._

class AdvancedLoadTestSimulation extends Simulation {

  val httpProtocol = http
    .baseUrl("https://postman-echo.com") 
    .acceptHeader("application/json")

  val scn = scenario("Simple Load Test with 10 Users")
    .exec(
      http("GET /get")
        .get("/get")
        .check(status.is(200))
    )

  setUp(
    scn.inject(
      atOnceUsers(10) // Inject 10 users at once
    )
  ).protocols(httpProtocol)
    .assertions(
      global.responseTime.percentile3.lt(1000), 
      global.successfulRequests.percent.gt(95)  
    )
}
